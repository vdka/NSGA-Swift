/***********************************************************
* This file contains the function prototypes for mh_misc.c *
***********************************************************/

/* Function Prototypes */

water_type read_water_file(string); 
void create_move_vector(int *,int,int);
void shuffle_move_vector(int *,int);

