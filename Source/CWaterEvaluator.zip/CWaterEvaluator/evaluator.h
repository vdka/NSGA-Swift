/* Constants */

#define num_non_solution_args 3

/* Type Definitions */

enum params{file_name_index=1,sol_length_index};
typedef enum params params_type;

/* Function Prototype */

void print_exit_message(char *[]);
