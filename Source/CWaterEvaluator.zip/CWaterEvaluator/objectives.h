/* Function Prototypes */

void evaluate_all_objectives(int, int, int, int*, int*, int*, float**, int*, int*, float*, float*,
                             int*);
float evaluate_net_revenue(int, int, int, int*, int*, float**, int*, float*);

void evaluate_environment_costs(int*, int*, int*);
