/*Function Prototypes */

float evaluate_total_constraint_violation(int *,float *,float **,int *,int,float,int,int,int *,int);
void calculate_allocation(int *,int *,int *);
void calculate_p(float *,int,float **,int *,int *);
